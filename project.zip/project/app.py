from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import os
from datetime import datetime
import pandas as pd
import csv
import base64
import numpy as np
import io
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

app = Flask(__name__)
app.secret_key = 'Shreewar@project'  

# Create products directory if it doesn't exist
if not os.path.exists('products'):
    os.makedirs('products')

# Warehouse options
warehouses = ['bengaluru', 'kocchi', 'chennai', 'kolkatta', 'mumbai', 'delhi', 'jaipur']

# Admin credentials file
admin_credentials_file = 'admin_credentials.csv'

# Ensure admin credentials file exists
if not os.path.isfile(admin_credentials_file):
    with open(admin_credentials_file, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['username', 'password', 'warehouse'])

# Load user credentials
user_credentials_file = 'users.csv'
if not os.path.isfile(user_credentials_file):
    with open(user_credentials_file, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['first_name', 'last_name', 'email', 'mobile'])

user_credentials = pd.read_csv(user_credentials_file)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        form_type = request.form['form_type']

        if form_type == 'register':
            username = request.form['username']
            password = request.form['password']
            repeat_password = request.form['repeat_password']
            warehouse = request.form['warehouse']

            if password != repeat_password:
                flash('Passwords do not match.', 'error')
                session['register_errors'] = True
                return redirect(url_for('admin_login'))

            with open(admin_credentials_file, 'a', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow([username, password, warehouse])

            flash('Registration successful. Please log in.', 'success')
            session.pop('register_errors', None)
            return redirect(url_for('admin_login'))

        elif form_type == 'login':
            username = request.form['username']
            password = request.form['password']
            warehouse = None

            with open(admin_credentials_file, 'r') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    if row['username'] == username and row['password'] == password:
                        warehouse = row['warehouse']
                        break

            if warehouse:
                session['admin_logged_in'] = True
                session['warehouse'] = warehouse
                session.pop('register_errors', None)
                return redirect(url_for('admin'))

            flash('Invalid credentials. Please try again.', 'error')
            return redirect(url_for('admin_login'))

    return render_template('admin_login.html', warehouses=warehouses)
@app.route('/admin')
def admin():
    if 'admin_logged_in' not in session or not session['admin_logged_in']:
        return redirect(url_for('admin_login'))

    # Get the warehouse of the logged-in admin
    admin_warehouse = session['warehouse']

    # List all CSV files in the products directory that belong to the admin
    existing_files = []
    for file in os.listdir('products'):
        if file.endswith('.csv') and admin_warehouse in file:
            existing_files.append(file)

    # Prepare existing dates
    existing_dates = {}
    for file in existing_files:
        filename = os.path.basename(file)
        filepath = os.path.join('products', file)
        df = pd.read_csv(filepath)
        existing_dates[filename] = df['date'].tolist()

    return render_template('admin.html', existing_files=existing_files, existing_dates=existing_dates)

@app.route('/create_new', methods=['POST'])
def create_new():
    if 'admin_logged_in' not in session or not session['admin_logged_in']:
        return redirect(url_for('admin_login'))

    product_name = request.form['product_name']
    admin_warehouse = session['warehouse']

    # Create new CSV file with admin's warehouse in the filename
    filename = f"{product_name}_{admin_warehouse}.csv"
    filepath = os.path.join('products', filename)

    # Check if file exists
    if os.path.isfile(filepath):
        return jsonify({'success': False, 'message': f'File "{filename}" already exists.'}), 400

    else:
        # Create the new CSV file with headers
        df = pd.DataFrame(columns=['date', 'product_name', 'sales', 'promotion'])
        df.to_csv(filepath, index=False)
        return jsonify({'success': True, 'message': f'File "{filename}" created successfully.'}), 200

    # return redirect(url_for('admin'))

@app.route('/upload', methods=['POST'])
def upload():
    if 'admin_logged_in' not in session or not session['admin_logged_in']:
        return redirect(url_for('admin_login'))

    file = request.files['file']
    if file:
        filename = file.filename
        admin_warehouse = session['warehouse']
        filename_with_warehouse = f"{os.path.splitext(filename)[0]}_{admin_warehouse}.csv"
        filepath = os.path.join('products', filename_with_warehouse)
        
        # Read the uploaded file into a DataFrame
        df = pd.read_csv(file)

        # Check if file exists
        if os.path.isfile(filepath):
            return jsonify({'success': False, 'message': f'File "{filename}" already exists.'}), 400
        else:
            # Save the file if it has at least 90 rows
            df.to_csv(filepath, index=False)
            return jsonify({'success': True, 'message': f'File "{filename}" uploaded successfully.'}), 200
    else:
        flash('No file selected.', 'error')

    return redirect(url_for('admin'))

@app.route('/update', methods=['POST'])
def update():
    if 'admin_logged_in' not in session or not session['admin_logged_in']:
        return redirect(url_for('admin_login'))

    selected_file = request.form['filename']
    admin_warehouse = session['warehouse']
    filename = os.path.basename(selected_file)
    filepath = os.path.join('products', filename)

    # Check if the selected file belongs to the logged-in admin
    if admin_warehouse not in filename:
        return jsonify({'success': False, 'message': 'Unauthorized access.'}), 403

    # Read existing data to check for unique date
    try:
        df = pd.read_csv(filepath)
        existing_dates = set(df['date'].tolist())
    except FileNotFoundError:
        return jsonify({'success': False, 'message': f'File "{filename}" not found.'}), 404

    date = request.form['date']
    sales = request.form['sales']
    promotion = request.form['promotion']

    # Validate fields
    if not date or not sales or not promotion:
        return jsonify({'success': False, 'message': 'All fields are required.'}), 400

    # Check if date already exists
    if date in existing_dates:
        return jsonify({'success': False, 'message': f'Date "{date}" already exists in "{filename}". Please choose a different date.'}), 400

    # Get product name from filename
    product_name = os.path.splitext(filename)[0].rsplit('_', 1)[0]

    # Append new data
    new_data = pd.DataFrame({
        'date': [date],
        'product_name': [product_name],
        'sales': [sales],
        'promotion': [promotion]
    })
    
    df = pd.concat([df, new_data], ignore_index=True)
    df.to_csv(filepath, index=False)

    return jsonify({'success': True, 'message': f'Data updated successfully in "{filename}".'}), 200

@app.route('/add_user', methods=['POST'])
def add_user():
    if 'admin_logged_in' not in session or not session['admin_logged_in']:
        return redirect(url_for('admin_login'))

    first_name = request.form['first_name']
    last_name = request.form['last_name']
    email = request.form['email']
    mobile = request.form['mobile']
    # password = request.form['password']

    if user_credentials[user_credentials['email'] == email].empty:
        with open('users.csv', 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([first_name, last_name, email, mobile])
        return jsonify({'success': True}), 200
    else:
        return jsonify({'success': False, 'message': 'Email already exists.'}), 400


@app.route('/user_login', methods=['GET', 'POST'])
def user_login():
    msg=None
    if request.method == 'POST':
        email = request.form['email']
        mobile = request.form['mobile']
        print(f"Received login attempt with email: {email} and mobile: {mobile}")
        user = (user_credentials['email'] == email) & (user_credentials['mobile'] == mobile)
        if not user.empty:
            session['user_logged_in'] = True
            session['email'] = email
            msg = f"User {email} logged in successfully."
            return redirect(url_for('user'))
        else:
            msg = 'Invalid credentials. Please try again.'
            print("Invalid credentials provided.")
            return render_template('user_login.html',msg=msg)
    return render_template('user_login.html',msg=msg)

@app.route('/user')
def user():
    if 'user_logged_in' not in session or not session['user_logged_in']:
        return redirect(url_for('user_login'))
    print(f"User {session['email']} is accessing the user page.")
    return render_template('user.html', warehouses=warehouses)

@app.route('/validate_product', methods=['POST'])
def validate_product():
    data = request.json
    product_name = data.get('product_name')
    warehouse = data.get('warehouse')
    
    products_folder = 'products'
    files = os.listdir(products_folder)
    
    for file in files:
        file_product, file_warehouse = file.rsplit('_', 1)[0], file.rsplit('_', 1)[-1].replace('.csv', '')
        if file_product == product_name and file_warehouse == warehouse:
            return jsonify({'success': True, 'message': 'Product and warehouse validated.'})
    
    return jsonify({'success': False, 'message': 'Product or warehouse not found.'})

@app.route('/data', methods=['POST', 'GET'])
def dataout():
    prediction_type = request.args.get('prediction_type')
    specific_date = request.args.get('specific_date')
    weekday = request.args.get('weekday')
    product_name = request.args.get('product_name')
    warehouse = request.args.get('warehouse')

    # Pass selected values to the template
    selected_options = {
        'prediction_type': prediction_type,
        'specific_date': specific_date,
        'weekday': weekday,
        'product_name': product_name,
        'warehouse': warehouse
    }

    file_path = f'products/{product_name}_{warehouse}.csv'

    if not os.path.exists(file_path):
        return f"Error: The file {file_path} does not exist.", 404
    mg = None
    ddf = pd.read_csv(file_path)
    if len(ddf) < 90:
        mg = f'File "{product_name}" should be more than 90 rows.'
        return render_template('user.html',mg = mg)
    else:
        data = pd.read_csv(file_path)
        data['date'] = pd.to_datetime(data['date'], format='%d-%m-%Y')
        data.set_index('date', inplace=True)

        data['month'] = data.index.month
        data['day_of_week'] = data.index.dayofweek

        if 'promotion' in data.columns:
            data['is_promotion'] = data['promotion'].apply(lambda x: 1 if x == 'yes' else 0)

        from sklearn.model_selection import train_test_split
        from sklearn.linear_model import LinearRegression

        X = data[['month', 'day_of_week']]
        if 'is_promotion' in data.columns:
            X['is_promotion'] = data['is_promotion']
        y = data['sales']

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        model = LinearRegression()
        model.fit(X_train, y_train)
        

        from sklearn.metrics import mean_absolute_error, mean_squared_error
        y_pred = model.predict(X_test)
        mae = mean_absolute_error(y_test, y_pred)
        rmse = mean_squared_error(y_test, y_pred, squared=False)
        scaled_mae = 100 * (1 - mae/np.mean(y_test))
        scaled_rmse = 100 * (1 - rmse/np.std(y_test))

        csv_last_date = data.index.max()

        future_start_date = csv_last_date + pd.Timedelta(days=1)

        future_end_date = future_start_date + pd.DateOffset(months=1) - pd.Timedelta(days=1)

        future_dates = pd.date_range(start=future_start_date, end=future_end_date)

        future_data = pd.DataFrame(future_dates, columns=['date'])
        future_data['month'] = future_data['date'].dt.month
        future_data['day_of_week'] = future_data['date'].dt.dayofweek
        future_data['is_promotion'] = 0

        future_predictions = model.predict(future_data[['month', 'day_of_week', 'is_promotion']])
        future_data['predicted_sales'] = future_predictions
        future_data['predicted_sales'] = future_data['predicted_sales'].astype(int)

        csv_start_date = data.index.min()
        csv_end_date = data.index.max()

        historical_data = pd.DataFrame({
            'date': pd.date_range(start=csv_start_date, end=csv_end_date),
            'sales': data['sales']
        })

        last_4_months = historical_data[historical_data['date'] >= historical_data['date'].max() - pd.DateOffset(months=3)]

        combined_data = pd.concat([last_4_months, future_data[['date', 'predicted_sales']]])
        last_5_historical = last_4_months.tail(5)
        ft = future_data.rename(columns={'predicted_sales': 'sales'})
        last_future_prediction = ft[['date', 'sales']].tail(1)
        combined_new = pd.concat([last_5_historical, last_future_prediction])

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(combined_data['date'], combined_data['sales'], marker='o', linestyle='-', color='b', label='Historical Sales')
        ax.plot(combined_new['date'], combined_new['sales'], marker='o', linestyle='-', color='g', label='Predicted Sales')
        ax.set_xlabel('Date')
        ax.set_ylabel('Sales')
        ax.set_title('Historical vs Predicted Sales')
        ax.legend()
        ax.grid(True)
        plt.xticks(rotation=350)

        output = io.BytesIO()
        FigureCanvas(fig).print_png(output)
        plt.close(fig)
        encoded_img = base64.b64encode(output.getvalue()).decode('utf-8')
        
        weekday_name = None
        if weekday is not None:
            weekday = int(weekday)
            weekday_name = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][weekday]

        average_sales = 0
        weekday_name = None
        type = None

        if prediction_type == 'specific_date' and specific_date:
            future_data = future_data[future_data['date'] == specific_date]
            average_sales = future_data['predicted_sales'].mean()
        elif prediction_type == 'weeks_of_month':
            average_sales = future_data['predicted_sales'].iloc[0:6].mean()*6
            type = "Weekly"
        elif prediction_type == 'weekdays' and weekday is not None:
            weekday = int(weekday)
            weekday_name = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][weekday]
            future_data = future_data[future_data['day_of_week'] == weekday]
            average_sales = future_data['predicted_sales'].mean()
            type = weekday_name
        elif prediction_type == 'whole_month':
            average_sales = int(future_data['predicted_sales'].mean())*30
            type = "Whole Month"
    return render_template('result.html', plot_url=encoded_img, future_data=future_data['predicted_sales'].head(1), selected_options=selected_options,average_sales=average_sales,weekday_name=weekday_name,type=type)

@app.route('/get_products/<warehouse>', methods=['GET'])
def get_products(warehouse):
    products_folder = 'products'
    files = os.listdir(products_folder)
    
    products = []
    for file in files:
        if file.endswith('.csv') and warehouse in file:
            product_name = file.rsplit('_', 1)[0]
            products.append(product_name)
    
    return jsonify(products)


@app.route('/show_demand', methods=['POST'])
def show_demand():
    product_name = request.form['product_name']
    warehouse = request.form['warehouse']
    months = int(request.form['months'])

    # Find the corresponding file for the product and warehouse
    filename = f"{product_name}_{warehouse}.csv"
    filepath = os.path.join('products', filename)
    
    # Load the product data
    df = pd.read_csv(filepath, parse_dates=['date'])

    # Predict future demand using Exponential Smoothing
    df['date'] = pd.to_datetime(df['date'])
    df.set_index('date', inplace=True)
    df = df.resample('M').sum()  # Resample monthly

    # Applying Exponential Smoothing
    from statsmodels.tsa.holtwinters import ExponentialSmoothing
    
    model = ExponentialSmoothing(df['sales'], trend='add', seasonal='add', seasonal_periods=12)
    fit = model.fit()
    prediction = fit.forecast(months)
    
    # Plot the sales and forecasted demand
    fig, ax = plt.subplots(figsize=(10, 6))
    df['sales'].plot(ax=ax, label='Actual Sales')
    prediction.plot(ax=ax, label='Forecasted Demand')
    
    plt.title(f'Demand Forecast for {product_name} in {warehouse}')
    plt.xlabel('Date')
    plt.ylabel('Sales')
    plt.legend()

    # Convert plot to PNG image
    png_image = base64.b64encode(fig_to_base64(fig)).decode('utf8')

    return render_template('demand_forecast.html', product_name=product_name, warehouse=warehouse, months=months, image=png_image)

def fig_to_base64(fig):
    png_image = BytesIO()
    FigureCanvas(fig).print_png(png_image)
    png_image.seek(0)
    return png_image.getvalue()

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
